#define SKETCH_NAME "IRfreqScout"
#define SKETCH_BUILD 1.5
#define SKETCH_REVISION "1.5"
