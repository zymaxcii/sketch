# DIY-Motion-Control

Arduino DIY Motion Control  Linear slide  with Speed control
